<?php
// Create a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "client_contact_db";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Create a new client
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["create_client"])) {
    // Validate and sanitize input data
    $client_name = trim($_POST["client_name"]);
    // Generate the client code
    $client_code = generate_client_code();
    // Perform necessary validation and sanitization checks here

    // Insert the client into the database
    $query = "INSERT INTO clients (Name, Code) VALUES ('$client_name', '$client_code')";
    if (mysqli_query($conn, $query)) {
        echo "Client created successfully.";
    } else {
        echo "Error creating client: " . mysqli_error($conn);
    }
}
// Create a new contact
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["create_contact"])) {
    // Validate and sanitize input data
    $client_name = trim($_POST["contact_name"]);
    // Generate the client code
    $client_code = generate_client_code();
    // Perform necessary validation and sanitization checks here

    // Insert the client into the database
    $query = "INSERT INTO contacts (name, surname, email) VALUES ('$contact_name', '$surname', '$surname')";
    if (mysqli_query($conn, $query)) {
        echo "Contact created successfully.";
    } else {
        echo "Error creating client: " . mysqli_error($conn);
    }
}


// Generate a new client code
function generate_client_code() {
    $letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $digits = "0123456789";
    $code = "";
    for ($i = 0; $i < 3; $i++) {
        $code .= $letters[rand(0, strlen($letters)-1)];
    }
    for ($i = 0; $i < 3; $i++) {
        $code .= $digits[rand(0, strlen($digits)-1)];
    }
    return $code;
}

// Query the database for the list of clients
$query = "SELECT clients.id, clients.name, clients.code, COUNT(contacts.id) AS num_contacts FROM clients LEFT JOIN contacts ON clients.id = contacts.client_id GROUP BY clients.id ORDER BY clients.name ASC";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo "Error retrieving client list: " . mysqli_error($conn);
} else if (mysqli_num_rows($result) > 0) {
    // Display the table of clients
    echo "<table>";
    echo "<thead><tr><th>Name</th><th>Client Code</th><th>No. of Linked Contacts</th></tr></thead>";
    echo "<tbody>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["code"] . "</td>";
        echo "<td>" . $row["num_contacts"] . "</td>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
} else {
    echo "No client(s) found";
}

// Close the database connection
mysqli_close($conn);
?>
<!DOCTYPE HTML>

<html>
	<head>
		<title>Client Contact Assignment Site</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<div class="logo">
							<span class="icon fa-gem"></span>
						</div>
						<div class="content">
							<div class="inner">
								<h1>Client Contact Assignment Site</h1>
								
							</div>
						</div>
						<nav>
							<ul>
								<li><a href="#nc">CREATE</a></li>
								<li><a href="#nco">VIEW </a></li>
								<li><a href="#nca">ASSIGN </a></li>
								
								<!--<li><a href="#elements">Elements</a></li>-->
							</ul>
						</nav>
					</header>

				<!-- Main -->
					<div id="main">

						<!--Client -->
							<article id="nc">
								<h1>Create a New Client / Contact</h1>
                              <form method="post" action="index.php">
                               <label for="client_name">Client Name:</label>
                               <input type="text" id="client_name" name="client_name" required>
                               <br>
                               <input type="submit" name="create_client" value="Create Client">
                               
							  
							  </form>
                            </article>
							 
							 <article id="nco">
								<h1>View Clients</h1>
                              <form method="post" action="index.php">
                               
                               <br>
                                 <table>
											<thead>
												<tr>
													<th>Name</th>
													<th>Code</th>
													<th>No. Of Linked Contacts</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Kawali</td>
													<td>KOK485</td>
													<td>0</td>
												</tr>
												
											</tbody>
											
										</table>                            
							   
							  </form>
                            </article>
							<article id="nca">
								<h1>Assign Clients</h1>
                              <form method="post" action="index.php">
                               
                               <br>
                                 <table>
											<thead>
												<tr>
													<th>Name</th>
													<th>Surname</th>
													<th>Email</th>
													<th>Select a Contact to Link</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>.......</td>
													<td>.......</td>
													<td>.......</td>
													<td>
													<label for="list">Select</label>
                                                    <select name="list" id="list">
                                                    </select>
                                                    </td>
												</tr>
												
											</tbody>
											
										</table>                            
							   
							  </form>
                            </article>
							<article id="nco">
								<h1>View Contacts</h1>
                              <form method="post" action="index.php">
                               <br>
							   <table>
											<thead>
												<tr>
													<th>Name</th>
													<th>Surname</th>
													<th>Email</th>
													<th>No. Of Linked Contacts</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>......</td>
													<td>......</td>
													<td>......</td>
													<td>......</td>
												</tr>
												
											</tbody>
											
										</table>       
							  
							  </form>
                            </article>
							
							
							<!--Contact -->
							<article id="nc">
								<h1 class="major">Add New Contact</h2>
								
								<form name="form1" method="post" action="">
								  <label for="name2">Name</label>
								  <input type="text" name="name" id="name" required>
								  <label for="">Surname</label>
								  <input type="text" name="surname" id="surname" required>
								  <label for="">Email Address</label>
								  <input type="text" name="email" id="email">
								  
								  
								  <div class="row">
						        <input class="btn" type="submit" name="submit"
							        id="submit_contact" value="Add Contact">
					            </div>
							  </form>
                            </article>

							

						<!-- Elements -->
							<article id="elements">
								<h2 class="major">Elements</h2>

								<section>
									<h3 class="major">Text</h3>
									<p>This is <b>bold</b> and this is <strong>strong</strong>. This is <i>italic</i> and this is <em>emphasized</em>.
									This is <sup>superscript</sup> text and this is <sub>subscript</sub> text.
									This is <u>underlined</u> and this is code: <code>for (;;) { ... }</code>. Finally, <a href="#">this is a link</a>.</p>
									<hr />
									<h2>Heading Level 2</h2>
									<h3>Heading Level 3</h3>
									<h4>Heading Level 4</h4>
									<h5>Heading Level 5</h5>
									<h6>Heading Level 6</h6>
									<hr />
									<h4>Blockquote</h4>
									<blockquote>Fringilla nisl. Donec accumsan interdum nisi, quis tincidunt felis sagittis eget tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan faucibus. Vestibulum ante ipsum primis in faucibus lorem ipsum dolor sit amet nullam adipiscing eu felis.</blockquote>
									<h4>Preformatted</h4>
									<pre><code>i = 0;

while (!deck.isInOrder()) {
    print 'Iteration ' + i;
    deck.shuffle();
    i++;
}

print 'It took ' + i + ' iterations to sort the deck.';</code></pre>
								</section>

								<section>
									<h3 class="major">Lists</h3>

									<h4>Unordered</h4>
									<ul>
										<li>Dolor pulvinar etiam.</li>
										<li>Sagittis adipiscing.</li>
										<li>Felis enim feugiat.</li>
									</ul>

									<h4>Alternate</h4>
									<ul class="alt">
										<li>Dolor pulvinar etiam.</li>
										<li>Sagittis adipiscing.</li>
										<li>Felis enim feugiat.</li>
									</ul>

									<h4>Ordered</h4>
									<ol>
										<li>Dolor pulvinar etiam.</li>
										<li>Etiam vel felis viverra.</li>
										<li>Felis enim feugiat.</li>
										<li>Dolor pulvinar etiam.</li>
										<li>Etiam vel felis lorem.</li>
										<li>Felis enim et feugiat.</li>
									</ol>
									<h4>Icons</h4>
									<ul class="icons">
										<li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
										<li><a href="#" class="icon brands fa-github"><span class="label">Github</span></a></li>
									</ul>

									<h4>Actions</h4>
									<ul class="actions">
										<li><a href="#" class="button primary">Default</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
									<ul class="actions stacked">
										<li><a href="#" class="button primary">Default</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
								</section>

								<section>
									<h3 class="major">Table</h3>
									<h4>Default</h4>
									<div class="table-wrapper">
										<table>
											<thead>
												<tr>
													<th>Name</th>
													<th>Description</th>
													<th>Price</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Item One</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Two</td>
													<td>Vis ac commodo adipiscing arcu aliquet.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Three</td>
													<td> Morbi faucibus arcu accumsan lorem.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Four</td>
													<td>Vitae integer tempus condimentum.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Five</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot>
										</table>
									</div>

									<h4>Alternate</h4>
									<div class="table-wrapper">
										<table class="alt">
											<thead>
												<tr>
													<th>Name</th>
													<th>Description</th>
													<th>Price</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Item One</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Two</td>
													<td>Vis ac commodo adipiscing arcu aliquet.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Three</td>
													<td> Morbi faucibus arcu accumsan lorem.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Four</td>
													<td>Vitae integer tempus condimentum.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Five</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot>
										</table>
									</div>
								</section>

								<section>
									<h3 class="major">Buttons</h3>
									<ul class="actions">
										<li><a href="#" class="button primary">Primary</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
									<ul class="actions">
										<li><a href="#" class="button">Default</a></li>
										<li><a href="#" class="button small">Small</a></li>
									</ul>
									<ul class="actions">
										<li><a href="#" class="button primary icon solid fa-download">Icon</a></li>
										<li><a href="#" class="button icon solid fa-download">Icon</a></li>
									</ul>
									<ul class="actions">
										<li><span class="button primary disabled">Disabled</span></li>
										<li><span class="button disabled">Disabled</span></li>
									</ul>
								</section>

								<section>
									<h3 class="major">Form</h3>
									<form method="post" action="#">
										<div class="fields">
											<div class="field half">
												<label for="demo-name">Name</label>
												<input type="text" name="demo-name" id="demo-name" value="" placeholder="Jane Doe" />
											</div>
											<div class="field half">
												<label for="demo-email">Email</label>
												<input type="email" name="demo-email" id="demo-email" value="" placeholder="jane@untitled.tld" />
											</div>
											<div class="field">
												<label for="demo-category">Category</label>
												<select name="demo-category" id="demo-category">
													<option value="">-</option>
													<option value="1">Manufacturing</option>
													<option value="1">Shipping</option>
													<option value="1">Administration</option>
													<option value="1">Human Resources</option>
												</select>
											</div>
											<div class="field half">
												<input type="radio" id="demo-priority-low" name="demo-priority" checked>
												<label for="demo-priority-low">Low</label>
											</div>
											<div class="field half">
												<input type="radio" id="demo-priority-high" name="demo-priority">
												<label for="demo-priority-high">High</label>
											</div>
											<div class="field half">
												<input type="checkbox" id="demo-copy" name="demo-copy">
												<label for="demo-copy">Email me a copy</label>
											</div>
											<div class="field half">
												<input type="checkbox" id="demo-human" name="demo-human" checked>
												<label for="demo-human">Not a robot</label>
											</div>
											<div class="field">
												<label for="demo-message">Message</label>
												<textarea name="demo-message" id="demo-message" placeholder="Enter your message" rows="6"></textarea>
											</div>
										</div>
										<ul class="actions">
											<li><input type="submit" value="Send Message" class="primary" /></li>
											<li><input type="reset" value="Reset" /></li>
										</ul>
									</form>
								</section>

							</article>

					</div>

				<!-- Footer -->
					<footer id="footer">
						<p class="copyright">&copy; Monica Design 2023</p>
					</footer>

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
